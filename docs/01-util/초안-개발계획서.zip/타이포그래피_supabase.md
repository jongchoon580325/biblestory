
## 📝 타이포그래피

### 폰트 스택
```css
font-family: 'Segoe UI', -apple-system, BlinkMacSystemFont, 'Roboto', sans-serif;
```

### 폰트 크기 체계
```css
/* 페이지 제목 */
.content-title { font-size: 32px; font-weight: 700; }
.book-chapter { font-size: 28px; font-weight: 600; }

/* 섹션 제목 */
.section-title { font-size: 20px; font-weight: bold; }
.section-header h1 { font-size: 24px; font-weight: 300; }

/* 본문 */
body { font-size: 16px; line-height: 1.6; }
.description { font-size: 18px; font-weight: 400; }
.verse-range { font-size: 16px; font-weight: 500; }

```

---
/* 반응형 최적화 */
@media (max-width: 768px) {
    .spiritual-application-card {
        padding: 25px 20px;
        margin: 25px 0;
    }
    
    .application-header h3 {
        font-size: 20px;
    }
    
    .application-content p {
        font-size: 15px;
    }
}
```

---

## 📱 반응형 디자인

### 브레이크포인트
```css
@media (max-width: 768px) {
    /* 모바일 스타일 */
}
```


## 🗄️ Supabase 데이터베이스 설계

## 📊 테이블 구조 설계

### 테이블 명명 규칙
- **접두어**: 모든 테이블명에 `b_` 접두어 사용
- **형식**: `b_테이블명` (예: `b_categories`, `b_bible_books`)
- **목적**: 데이터베이스 구조 명확성 및 네임스페이스 관리

### 1. 카테고리 테이블 (b_categories)
```sql
CREATE TABLE b_categories (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name VARCHAR(50) NOT NULL UNIQUE, -- '구약', '신약'
  display_name VARCHAR(100) NOT NULL, -- '구약 성경', '신약 성경'
  color_theme VARCHAR(20) NOT NULL, -- 'old-testament', 'new-testament'
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 기본 데이터 삽입
INSERT INTO b_categories (name, display_name, color_theme, sort_order) VALUES
('old-testament', '구약 성경', 'old-testament', 1),
('new-testament', '신약 성경', 'new-testament', 2);
```

### 2. 성경 책 테이블 (b_bible_books)
```sql
CREATE TABLE b_bible_books (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  category_id UUID REFERENCES b_categories(id) ON DELETE CASCADE,
  name VARCHAR(50) NOT NULL, -- '창세기', '마태복음'
  name_english VARCHAR(50), -- 'Genesis', 'Matthew'
  abbreviation VARCHAR(10), -- '창', '마'
  sort_order INTEGER NOT NULL,
  total_chapters INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(category_id, name)
);

-- 구약 성경 기본 데이터 (예시)
INSERT INTO b_bible_books (category_id, name, name_english, abbreviation, sort_order, total_chapters) 
SELECT c.id, '창세기', 'Genesis', '창', 1, 50 FROM b_categories c WHERE c.name = 'old-testament'
UNION ALL
SELECT c.id, '출애굽기', 'Exodus', '출', 2, 40 FROM b_categories c WHERE c.name = 'old-testament'
UNION ALL
-- 신약 성경 기본 데이터 (예시)
SELECT c.id, '마태복음', 'Matthew', '마', 1, 28 FROM b_categories c WHERE c.name = 'new-testament'
UNION ALL
SELECT c.id, '마가복음', 'Mark', '막', 2, 16 FROM b_categories c WHERE c.name = 'new-testament';
```

### 3. 업로드 파일 테이블 (b_uploaded_files)
```sql
CREATE TABLE b_uploaded_files (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  filename VARCHAR(255) NOT NULL,
  original_filename VARCHAR(255) NOT NULL,
  file_size BIGINT NOT NULL,
  content_type VARCHAR(100) NOT NULL,
  file_path VARCHAR(500) NOT NULL, -- Supabase Storage 경로
  upload_status VARCHAR(20) NOT NULL DEFAULT 'uploaded', -- 'uploaded', 'processing', 'completed', 'failed'
  raw_content TEXT, -- 원본 텍스트 내용
  user_id UUID, -- 향후 사용자 인증 시 활용
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 인덱스 생성
CREATE INDEX idx_b_uploaded_files_status ON b_uploaded_files(upload_status);
CREATE INDEX idx_b_uploaded_files_created ON b_uploaded_files(created_at DESC);
```

### 4. 변환 작업 테이블 (b_conversion_jobs)
```sql
CREATE TABLE b_conversion_jobs (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  uploaded_file_id UUID REFERENCES b_uploaded_files(id) ON DELETE CASCADE,
  status VARCHAR(20) NOT NULL DEFAULT 'pending', -- 'pending', 'processing', 'completed', 'failed'
  progress_percentage INTEGER DEFAULT 0 CHECK (progress_percentage >= 0 AND progress_percentage <= 100),
  ai_analysis JSONB, -- OpenAI 분석 결과
  error_message TEXT,
  processing_started_at TIMESTAMP WITH TIME ZONE,
  processing_completed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 인덱스 생성
CREATE INDEX idx_b_conversion_jobs_status ON b_conversion_jobs(status);
CREATE INDEX idx_b_conversion_jobs_file ON b_conversion_jobs(uploaded_file_id);
```

### 5. 성경 콘텐츠 테이블 (b_bible_contents)
```sql
CREATE TABLE b_bible_contents (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  subtitle VARCHAR(300),
  bible_book_id UUID REFERENCES b_bible_books(id) ON DELETE SET NULL,
  chapter_number INTEGER,
  verse_range VARCHAR(50), -- '1:1-31', '3:1-17' 등
  theme_type VARCHAR(20) NOT NULL, -- 'old-testament', 'new-testament'
  
  -- 콘텐츠 관련
  html_content TEXT NOT NULL, -- 생성된 HTML 콘텐츠
  components_used JSONB, -- 사용된 컴포넌트 목록
  color_palette JSONB, -- 사용된 색상 정보
  
  -- 메타데이터
  word_count INTEGER DEFAULT 0,
  estimated_reading_time INTEGER DEFAULT 0, -- 분 단위
  difficulty_level VARCHAR(20) DEFAULT 'intermediate', -- 'beginner', 'intermediate', 'advanced'
  target_audience VARCHAR(50) DEFAULT 'general', -- 'children', 'youth', 'adult', 'general'
  
  -- 파일 연결
  source_file_id UUID REFERENCES b_uploaded_files(id) ON DELETE SET NULL,
  conversion_job_id UUID REFERENCES b_conversion_jobs(id) ON DELETE SET NULL,
  
  -- 상태 관리
  status VARCHAR(20) NOT NULL DEFAULT 'draft', -- 'draft', 'published', 'archived'
  is_featured BOOLEAN DEFAULT false,
  view_count INTEGER DEFAULT 0,
  
  -- 타임스탬프
  published_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 인덱스 생성
CREATE INDEX idx_b_bible_contents_book_chapter ON b_bible_contents(bible_book_id, chapter_number);
CREATE INDEX idx_b_bible_contents_theme ON b_bible_contents(theme_type);
CREATE INDEX idx_b_bible_contents_status ON b_bible_contents(status);
CREATE INDEX idx_b_bible_contents_featured ON b_bible_contents(is_featured) WHERE is_featured = true;
CREATE INDEX idx_b_bible_contents_published ON b_bible_contents(published_at DESC) WHERE status = 'published';
```

### 6. 태그 시스템 (선택사항)
```sql
CREATE TABLE b_tags (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name VARCHAR(50) NOT NULL UNIQUE,
  color VARCHAR(7) DEFAULT '#3498db', -- 헥스 컬러
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE b_bible_content_tags (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  bible_content_id UUID REFERENCES b_bible_contents(id) ON DELETE CASCADE,
  tag_id UUID REFERENCES b_tags(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(bible_content_id, tag_id)
);
```

---

## 🔒 개발 단계 권한 설정

### RLS (Row Level Security) 정책

```sql
-- 모든 테이블에 대해 RLS 활성화
ALTER TABLE b_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE b_bible_books ENABLE ROW LEVEL SECURITY;
ALTER TABLE b_uploaded_files ENABLE ROW LEVEL SECURITY;
ALTER TABLE b_conversion_jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE b_bible_contents ENABLE ROW LEVEL SECURITY;
ALTER TABLE b_tags ENABLE ROW LEVEL SECURITY;
ALTER TABLE b_bible_content_tags ENABLE ROW LEVEL SECURITY;
```

### 개발 환경 정책 (관대한 접근)

```sql
-- 개발 환경: 모든 사용자가 모든 데이터에 접근 가능
CREATE POLICY "dev_full_access_b_categories" ON b_categories FOR ALL USING (true);
CREATE POLICY "dev_full_access_b_bible_books" ON b_bible_books FOR ALL USING (true);
CREATE POLICY "dev_full_access_b_uploaded_files" ON b_uploaded_files FOR ALL USING (true);
CREATE POLICY "dev_full_access_b_conversion_jobs" ON b_conversion_jobs FOR ALL USING (true);
CREATE POLICY "dev_full_access_b_bible_contents" ON b_bible_contents FOR ALL USING (true);
CREATE POLICY "dev_full_access_b_tags" ON b_tags FOR ALL USING (true);
CREATE POLICY "dev_full_access_b_bible_content_tags" ON b_bible_content_tags FOR ALL USING (true);
```

### 개발용 환경 변수
```env
# .env.local
NEXT_PUBLIC_SUPABASE_URL=your-dev-project-url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-dev-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-dev-service-role-key
OPENAI_API_KEY=your-openai-api-key
NODE_ENV=development
```

---

## 🚀 배포 단계 권한 설정

### 운영 환경 보안 정책

```sql
-- 기본적으로 모든 접근 차단
DROP POLICY IF EXISTS "dev_full_access_b_categories" ON b_categories;
DROP POLICY IF EXISTS "dev_full_access_b_bible_books" ON b_bible_books;
DROP POLICY IF EXISTS "dev_full_access_b_uploaded_files" ON b_uploaded_files;
DROP POLICY IF EXISTS "dev_full_access_b_conversion_jobs" ON b_conversion_jobs;
DROP POLICY IF EXISTS "dev_full_access_b_bible_contents" ON b_bible_contents;
DROP POLICY IF EXISTS "dev_full_access_b_tags" ON b_tags;
DROP POLICY IF EXISTS "dev_full_access_b_bible_content_tags" ON b_bible_content_tags;

-- 읽기 전용 데이터 (카테고리, 성경책 정보)
CREATE POLICY "public_read_b_categories" ON b_categories FOR SELECT USING (true);
CREATE POLICY "public_read_b_bible_books" ON b_bible_books FOR SELECT USING (true);
CREATE POLICY "public_read_b_tags" ON b_tags FOR SELECT USING (true);

-- 발행된 콘텐츠만 공개
CREATE POLICY "public_read_published_contents" ON b_bible_contents 
  FOR SELECT USING (status = 'published');

-- 업로드 파일: 서비스 역할만 접근
CREATE POLICY "service_role_b_uploaded_files" ON b_uploaded_files 
  FOR ALL USING (auth.role() = 'service_role');

-- 변환 작업: 서비스 역할만 접근  
CREATE POLICY "service_role_b_conversion_jobs" ON b_conversion_jobs 
  FOR ALL USING (auth.role() = 'service_role');

-- 콘텐츠 관리: 서비스 역할만 수정 가능
CREATE POLICY "service_role_manage_contents" ON b_bible_contents 
  FOR INSERT WITH CHECK (auth.role() = 'service_role');
CREATE POLICY "service_role_update_contents" ON b_bible_contents 
  FOR UPDATE USING (auth.role() = 'service_role');
CREATE POLICY "service_role_delete_contents" ON b_bible_contents 
  FOR DELETE USING (auth.role() = 'service_role');

-- 태그 연결: 서비스 역할만 관리
CREATE POLICY "service_role_b_bible_content_tags" ON b_bible_content_tags 
  FOR ALL USING (auth.role() = 'service_role');
```

### Storage 버킷 설정

**버킷 명명 규칙:**
- **형식**: 특수기호, 띄어쓰기 없이 영문으로만 구성
- **예시**: `biblefiles`, `biblehtmlfiles`, `bibleuploads`

```sql
-- 파일 업로드용 버킷 생성
INSERT INTO storage.buckets (id, name, public) VALUES ('biblefiles', 'biblefiles', false);

-- Storage 정책 설정
CREATE POLICY "service_upload_files" ON storage.objects 
  FOR INSERT WITH CHECK (
    bucket_id = 'biblefiles' AND 
    auth.role() = 'service_role'
  );

CREATE POLICY "service_read_files" ON storage.objects 
  FOR SELECT USING (bucket_id = 'biblefiles');

CREATE POLICY "service_delete_files" ON storage.objects 
  FOR DELETE USING (
    bucket_id = 'biblefiles' AND 
    auth.role() = 'service_role'
  );
```

### 운영용 환경 변수
```env
# .env.production
NEXT_PUBLIC_SUPABASE_URL=your-prod-project-url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-prod-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-prod-service-role-key
OPENAI_API_KEY=your-openai-api-key
NODE_ENV=production
```

---

## 📈 성능 최적화 및 모니터링

### 필수 인덱스 점검
```sql
-- 성능 중요 쿼리용 복합 인덱스
CREATE INDEX idx_b_contents_book_status_published ON b_bible_contents(bible_book_id, status, published_at DESC) 
  WHERE status = 'published';

CREATE INDEX idx_b_contents_theme_featured ON b_bible_contents(theme_type, is_featured, created_at DESC) 
  WHERE is_featured = true;

-- 파일 처리 성능용 인덱스
CREATE INDEX idx_b_files_processing_status ON b_uploaded_files(upload_status, created_at) 
  WHERE upload_status IN ('uploaded', 'processing');
```

### 데이터베이스 함수 (편의 기능)

```sql
-- 콘텐츠 통계 함수
CREATE OR REPLACE FUNCTION get_content_stats()
RETURNS TABLE (
  total_contents BIGINT,
  old_testament_count BIGINT,
  new_testament_count BIGINT,
  published_count BIGINT,
  draft_count BIGINT
) AS $
BEGIN
  RETURN QUERY
  SELECT 
    COUNT(*) as total_contents,
    COUNT(*) FILTER (WHERE theme_type = 'old-testament') as old_testament_count,
    COUNT(*) FILTER (WHERE theme_type = 'new-testament') as new_testament_count,
    COUNT(*) FILTER (WHERE status = 'published') as published_count,
    COUNT(*) FILTER (WHERE status = 'draft') as draft_count
  FROM b_bible_contents;
END;
$ LANGUAGE plpgsql;

-- 인기 콘텐츠 조회 함수
CREATE OR REPLACE FUNCTION get_popular_contents(limit_count INTEGER DEFAULT 10)
RETURNS TABLE (
  id UUID,
  title VARCHAR(200),
  view_count INTEGER,
  theme_type VARCHAR(20)
) AS $
BEGIN
  RETURN QUERY
  SELECT bc.id, bc.title, bc.view_count, bc.theme_type
  FROM b_bible_contents bc
  WHERE bc.status = 'published'
  ORDER BY bc.view_count DESC, bc.created_at DESC
  LIMIT limit_count;
END;
$ LANGUAGE plpgsql;
```

### 백업 및 복구 계획

```sql
-- 정기 백업을 위한 뷰 생성
CREATE VIEW backup_essential_data AS
SELECT 
  'b_bible_contents' as table_name,
  COUNT(*) as record_count,
  MAX(updated_at) as last_updated
FROM b_bible_contents
UNION ALL
SELECT 
  'b_uploaded_files' as table_name,
  COUNT(*) as record_count,
  MAX(updated_at) as last_updated  
FROM b_uploaded_files;

-- 데이터 무결성 검사 함수
CREATE OR REPLACE FUNCTION check_data_integrity()
RETURNS TABLE (
  table_name TEXT,
  issue_type TEXT,
  issue_count BIGINT
) AS $
BEGIN
  -- 고아 레코드 검사
  RETURN QUERY
  SELECT 
    'b_bible_contents' as table_name,
    'orphaned_books' as issue_type,
    COUNT(*) as issue_count
  FROM b_bible_contents bc
  LEFT JOIN b_bible_books bb ON bc.bible_book_id = bb.id
  WHERE bc.bible_book_id IS NOT NULL AND bb.id IS NULL;
  
  -- 더 많은 무결성 검사 추가 가능
END;
$ LANGUAGE plpgsql;
```

---

## 🔧 개발 편의 기능

### Supabase CLI 명령어 모음

```bash
# 로컬 개발 환경 시작
supabase start

# 마이그레이션 생성
supabase db diff --use-migra -f initial_schema

# 마이그레이션 적용
supabase db push

# 타입 생성 (TypeScript)
supabase gen types typescript --local > types/supabase.ts

# 시드 데이터 실행
supabase db seed

# 로컬 대시보드 접근
supabase dashboard
```

### 개발용 시드 데이터

```sql
-- 개발용 샘플 데이터 (seed.sql)
INSERT INTO b_bible_contents (
  title,
  subtitle, 
  bible_book_id,
  chapter_number,
  verse_range,
  theme_type,
  html_content,
  status,
  published_at
) 
SELECT 
  '창세기 1장 - 하나님의 창조',
  '태초에 하나님이 천지를 창조하시다',
  bb.id,
  1,
  '1:1-31',
  'old-testament',
  '<div>샘플 HTML 콘텐츠</div>',
  'published',
  NOW()
FROM b_bible_books bb 
WHERE bb.name = '창세기';
```

이제 **완전한 데이터베이스 아키텍처**로 견고하고 확장 가능한 시스템을 구축할 수 있겠네요!

---
